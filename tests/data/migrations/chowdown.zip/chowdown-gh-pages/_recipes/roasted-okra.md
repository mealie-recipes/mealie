---

layout: recipe
title: "Roasted Okra"
image: roasted-okra.jpg
tags: sides, vegetables

ingredients:
- 1 bunch of okra
- salt, pepper, etc to taste

directions:
- Wash the okra dang good
- Slice in half lengthwise
- Toss okra and seasoning on baking sheet (salt + pepper is great, I also really like Simply Asia spicy hibachi seasoing I found at HEB for like $2)
- Roast under the broiler for 10-15 mins. Keep an eye on it and pull it when the tips start to blacken.

---

I love me some okra, but prep is usually enough to avoid making it. This simple dish requires only a single cut per pod and a dash of seasoning- that's it.