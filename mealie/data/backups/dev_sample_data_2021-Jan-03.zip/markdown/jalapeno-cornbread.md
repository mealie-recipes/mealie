

![Recipe Image](../images/jalapeno-cornbread.jpg)

# Jalapeno Cornbread

## Ingredients

- [ ] 1 box "fiesta" corn bread mix

- [ ] 1 can of sweet corn

- [ ] 1 cup sour cream

- [ ] pickled jalapeños to taste


## Instructions

- [ ] Make the cornbread mix according to the box (usually needs eggs and milk).

- [ ] Add a full can or corn (a regular sized can) and the sour cream (1 cup).

- [ ] Pour into a large glass baking dish and top with jalapeños.

- [ ] Bake a few mins longer than the box says (we've added a lot of liquid).




---

Tags: ['sides', ' bread', ' spicy']
Categories: []
Original URL: 