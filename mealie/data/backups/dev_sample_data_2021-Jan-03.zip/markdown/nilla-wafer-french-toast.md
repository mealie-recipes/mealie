

![Recipe Image](../images/nilla-wafer-french-toast.jpg)

# Nilla Wafer French Toast

## Ingredients

- [ ] 4 eggs

- [ ] 1/4 cup heavy cream

- [ ] 2 tsp vanilla

- [ ] sprinkle of sugar

- [ ] 4 cups Nilla Wafers Minis


## Instructions

- [ ] Beat the eggs, heavy cream, vanilla, and sugar.

- [ ] Arrange the nillas in a few flat layers in a baking dish.

- [ ] Pour egg mixture over nillas. Let soak while oven preheats to 350°. Top with shake of cinnamon sugar.

- [ ] Bake until egg has set (it'll fluff up a bit)




---

Tags: ['breakfast', ' baking']
Categories: []
Original URL: 