

![Recipe Image](../images/marranitos-enfiestados.jpg)

# Marranitos Enfiestados

## Ingredients

- [ ] 1½ cups (210 g) whole wheat flour

- [ ] 1 Tbsp. ground cinnamon

- [ ] 1 Tbsp. ground ginger

- [ ] 1 tsp. ground allspice

- [ ] ¼ tsp. ground cloves

- [ ] 1 tsp. baking powder

- [ ] ½ tsp. baking soda

- [ ] 3¾ cups (469 g) all-purpose flour, plus more for dusting

- [ ] 12 Tbsp. (1½ sticks) unsalted butter, room temperature, divided

- [ ] ½ cup (100 g) plus 1 tsp. granulated sugar

- [ ] 1¼ tsp. Diamond Crystal or ¾ tsp. Morton kosher salt, divided

- [ ] 3 large eggs, room temperature

- [ ] 2 tsp. vanilla extract, divided

- [ ] ⅓ cup light agave syrup (nectar), honey, or light corn syrup

- [ ] ½ cup (100 g) grated or granulated piloncillo or (packed) dark brown sugar

- [ ] ⅓ cup robust-flavored (dark) molasses

- [ ] Nonstick vegetable oil spray

- [ ] Sanding sugar or sprinkles (for decorating)

- [ ] A 4" pig-shaped cookie cutter


## Instructions

- [ ] Whisk whole wheat flour, cinnamon, ginger, allspice, cloves, baking powder, baking soda, and 3¾ cups (469 g) all-purpose flour in a medium bowl. Using an electric mixer on medium-high speed, beat 6 Tbsp. butter, ½ cup (100 g) granulated sugar, and half of salt in a large bowl, scraping down sides of bowl as needed, until light and creamy, about 3 minutes. Add 1 egg and 1 tsp. vanilla; beat to combine. Add agave and beat just until smooth. Reduce speed to low, add half of dry ingredients (if you have a scale, use it!), and beat to combine, scraping down sides of bowl as needed. Dough will be slightly sticky. Wrap in plastic; pat into a square about ¾" thick. Chill at least 3 hours and up to 1 day.

- [ ] Clean bowl and beaters. With mixer on medium-high speed, beat piloncillo, remaining salt, and remaining 6 Tbsp. butter, scraping down sides of bowl as needed, until light and creamy, about 3 minutes. Add 1 egg and remaining 1 tsp. vanilla; beat until combined. Add molasses and beat until smooth. Reduce speed to low; beat in remaining dry ingredients, scraping down sides of bowl as needed. Wrap in plastic; pat into a square about ¾" thick. Chill at least 3 hours and up to 1 day.

- [ ] Place racks in upper and lower thirds of oven; preheat to 350°. Line 3 baking sheets with parchment paper and lightly coat with nonstick spray. Cut both doughs into about ¾" pieces. (Don’t worry about being super precise; spots will look better if pieces are different shapes and sizes.) Arrange about half of brown and white dough pieces, touching and alternating colors, in an even layer on a lightly floured piece of parchment. (Chill remaining dough while you work.) Roll out ¼" thick. Punch out cookies with lightly floured cutter and transfer to prepared baking sheets, spacing ¾" apart. Arrange scraps in a single layer so they are touching and cover with plastic; chill 10 minutes if soft. Roll out scraps and cut out more pigs. Repeat with remaining dough and scraps.

- [ ] Beat remaining egg and remaining 1 tsp. granulated sugar in a small bowl. Using your finger, rub egg on brown spots only (egg will darken the spots) and along edges of cookies. Sprinkle sanding sugar or sprinkles along the edges of cookies, gently pressing into dough to adhere. Chill 10 minutes.

- [ ] Working in batches, bake cookies, rotating baking sheets top to bottom and front to back halfway through, until puffed and light spots are golden, 10–12 minutes. Let cookies cool 10 minutes on baking sheets, then transfer to a wire rack. Let cool completely.
Do ahead: Cookies can be made 2 days ahead. Store airtight at room temperature.




---

Tags: []
Categories: []
Original URL: https://www.bonappetit.com/recipe/marranitos-enfiestados