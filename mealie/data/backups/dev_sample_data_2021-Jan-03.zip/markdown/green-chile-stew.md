

![Recipe Image](../images/green-chile-stew.jpg)

# Green Chile Stew

## Ingredients

- [ ] 1 jar of [green chile stew mix](http://amzn.to/1KYXSjo)

- [ ] 1lb ground chicken

- [ ] 1 red onion

- [ ] 1 green onion

- [ ] 1 can corn


## Instructions

- [ ] Start onions in pan, cook down

- [ ] Add chicken, corn

- [ ] Add stew mix

- [ ] Serve with croutons




---

Tags: ['sides', ' soups']
Categories: []
Original URL: 