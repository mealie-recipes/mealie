

![Recipe Image](../images/one-minute-muffin.jpg)

# One Minute Muffin

## Ingredients

- [ ] 1⁄4 cup flax seed meal

- [ ] 1⁄2 teaspoon baking powder

- [ ] 1 teaspoon cinnamon

- [ ] 1 egg

- [ ] 1 teaspoon oil

- [ ] sugar to taste (or honey, stevia)


## Instructions

- [ ] Mix all ingredients in a coffee mug.

- [ ] Micorowave for one minute on high.




---

Tags: ['breakfast']
Categories: []
Original URL: 