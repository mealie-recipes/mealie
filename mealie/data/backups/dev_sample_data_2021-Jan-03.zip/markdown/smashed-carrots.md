

![Recipe Image](../images/smashed-carrots.jpg)

# Smashed Carrots

## Ingredients

- [ ] 1 can carrots

- [ ] 1 tbsp butter

- [ ] 2 tbsp parmesan cheese

- [ ] salt & pepper to taste


## Instructions

- [ ] Combine carrots and butter, heat through (yes, you can microwave)

- [ ] Mash carrots, adding parmesan when smooshy

- [ ] Salt and pepper how you like




---

Tags: ['sides', ' vegetables']
Categories: []
Original URL: 