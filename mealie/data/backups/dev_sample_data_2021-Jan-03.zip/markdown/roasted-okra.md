

![Recipe Image](../images/roasted-okra.jpg)

# Roasted Okra

## Ingredients

- [ ] 1 bunch of okra

- [ ] salt, pepper, etc to taste


## Instructions

- [ ] Wash the okra dang good

- [ ] Slice in half lengthwise

- [ ] Toss okra and seasoning on baking sheet (salt + pepper is great, I also really like Simply Asia spicy hibachi seasoing I found at HEB for like $2)

- [ ] Roast under the broiler for 10-15 mins. Keep an eye on it and pull it when the tips start to blacken.




---

Tags: ['sides', ' vegetables']
Categories: []
Original URL: 