

![Recipe Image](../images/pace-pork.jpg)

# Pace Pork

## Ingredients

- [ ] pork shoulder (or loin)

- [ ] 1 jar of Pace Picante


## Instructions

- [ ] Combine the pork and Pace Picante in the crockpot

- [ ] Cook on slow for 8hrs or so (until it shreds)

- [ ] Eat on buns, on tortillas, with chips or nachos, etc




---

Tags: ['mains', ' crock pot']
Categories: []
Original URL: 