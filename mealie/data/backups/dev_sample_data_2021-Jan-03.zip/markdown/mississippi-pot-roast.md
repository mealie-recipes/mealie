

![Recipe Image](../images/mississippi-pot-roast.jpg)

# Mississippi Pot Roast

## Ingredients

- [ ] 3-4 lbs chuck roast

- [ ] 1 packet ranch mix

- [ ] 1 packet au jus gravy mix

- [ ] 1 stick butter

- [ ] 1 jar pepperoncinis


## Instructions

- [ ] In your slow cooker, add the roast and top with both packet mixes, a stick of butter (sliced into a few chunks), and a jar of pepperoncini peppers (the more the better, drained)

- [ ] Cook for 8 hours on low

- [ ] Serve with salt & vinegar potatoes




---

Tags: ['mains', ' crock pot']
Categories: []
Original URL: 