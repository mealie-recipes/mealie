

![Recipe Image](../images/roasted-brussels-sprouts.jpg)

# Roasted Brussels Sprouts

## Ingredients

- [ ] 1 bunch of brussels, sliced thin

- [ ] 2 tbsp olive oil

- [ ] (optional) grated hard cheese

- [ ] (optional) gold raisins or sweetened cranberries

- [ ] (optional) assorted veggies, sliced thin

- [ ] salt, pepper, etc to taste


## Instructions

- [ ] Wash and thinly slice the brussels sprouts (or buy them pre-sliced at HEB or Central Market)

- [ ] Toss the brussels (+ optional veggies), olive oil, and salt + pepper on a baking sheet

- [ ] Roast under the broiler for 10-15 mins, keeping a close eye

- [ ] Remove from the oven when the edges just start to blacken

- [ ] Toss with optional ingredients (depending on how healthy you're feeling)




---

Tags: ['sides', ' vegetables']
Categories: []
Original URL: 