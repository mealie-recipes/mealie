

![Recipe Image](../images/downtown-marinade.jpg)

# Downtown Marinade

## Ingredients

- [ ] 1 cup Italian dressing

- [ ] 1/4 cup soy sauce

- [ ] 1/4 cup chili paste (like [sambal oelek](https://amzn.to/2NuqquF))

- [ ] 1/4 sugar

- [ ] dash hot sauce (like Texas Champagne or Yellowbird)


## Instructions

- [ ] Mix everythiing in a large zip bag (or bowl)

- [ ] Toss meat and let sit (from 1-36hr)




---

Tags: ['party', ' meat']
Categories: []
Original URL: 