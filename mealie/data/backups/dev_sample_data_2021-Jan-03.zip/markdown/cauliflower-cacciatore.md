

![Recipe Image](../images/cauliflower-cacciatore.jpg)

# Cauliflower Cacciatore

## Ingredients

- [ ] 1 head of cauliflower

- [ ] 1lb mini sweet peppers

- [ ] 1 yellow onion, diced

- [ ] 5oz mild goat cheese (we like Chavrie brand)

- [ ] 5oz sour cream

- [ ] jar of cacciatore sauce (we like Cookwell & Company)

- [ ] 1 cup red wine

- [ ] croutons (we make our own)

- [ ] fresh cilantro


## Instructions

- [ ] Start by pickling half your peppers. Chop all your peppers, put half in a jar, cover with vinegar (and whatever you like, spices, garlic, hot sauce). We're only looking for a quick pickle here, so do this, shake it up, and get back to the rest of the recipe.

- [ ] Next, start roasting the cauliflower, around 350°, to your desired level of doneness. Keep it firm and you can call it a "cauliflower steak", cook it down hard and it'll eat more like a mash. If you're making your own croutons, add some bread cubes tossed in oil/salt/pepper around the roasting pan.

- [ ] While the cauliflower roasts, stir the goat cheese and sour cream together (and whatever you like, spices, garlic, hot sauce). If it's too thick, thin it out with a bit of olive oil.

- [ ] Cook the onion and remaining peppers (non-pickled!) in a high heat pan with some olive oil. When softened, add your jar of cacciatore sauce and a cup of red wine. Stir and bring to a simmer, let it go until it gets a bit thicker.

- [ ] To assemble, plate a large dollop of our cream cheese spread, place half a cauliflower head on top, cover with a scoop of cacciatore sauce, top with croutons, cilantro, and our pickled peppers.




---

Tags: ['mains', ' veg']
Categories: []
Original URL: 